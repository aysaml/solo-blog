title: Docker入门
date: '2019-05-05 17:18:18'
updated: '2019-05-05 17:19:13'
tags: [Docker]
permalink: /articles/2019/05/05/1557047898603.html
---
![](https://img.hacpai.com/bing/20171218.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1. 应用部署难题

试想一下，你要把一个web应用以war包的形式部署在一台linux服务器上，你需要安装jdk,你要配置环境变量，你要安装tomcat...以及各种库和组件。换一台机器，这些麻烦的步骤还要重来一遍。所以人们就在想，有没有一种方式，规避这些烦人的环境问题，让开发者的关注点在应用本身，一次环境设置，可以部署到任何一个机器上面。

### 2. 解决方案
* 虚拟机

	虚拟机是一种解决方案，它可以在一个操作系统中运行另一个操作系统。在安装软件时，先安装一个配置好环境的虚拟机，就跳过了多次进行环境设置的麻烦。

	虽然用户可以用这种方法还原系统环境，但是这种方案有几个缺点：
	
	* 资源占用多
		除了应用必要的环境外，虚拟机会独占一部分资源和内存，即使应用程序仅仅使用1MB的资源，虚拟机运行还是会占用几百M的资源。
	* 冗余步骤多
		因为虚拟机是一个独立的操作系统，所以不能跳过一些必要的步骤，如用户登录等，而应用并不关注这些。
	* 启动慢 
		虚拟机建立在操作系统上，操作系统启动耗费多少时间，虚拟机就耗费多少时间。

* Linux容器

	Linux 容器不是模拟一个完整的操作系统，而是对进程进行隔离。**或者说，在正常进程的外面套了一个[保护层](https://opensource.com/article/18/1/history-low-level-container-runtimes)。对于容器里面的进程来说，它接触到的各种资源都是虚拟的，从而实现与底层系统的隔离。

	相比较虚拟机，Linux容器有下面几个优点：

	* 启动速度快
	在Linux容器中，应用就是系统的一个进程，启动一个进程相比启动一个操作系统，速度快了很多。
	* 资源占用少
	容器只占用其需要的资源，相比虚拟机，不需要独占一部分系统运行需要的资源，并且各个容器之间的资源可以共享。
	* 体积小
	在容器中，应用只需要包含必要的库和组件，而不是整个虚拟机系统，所以体积上面会有很大的不同。

* Docker

	类似java开发常用的spring和spring boot之间的关系，Docker在容器的基础上进行了封装，为开发者提供简单易用的容器使用接口。Docker 将应用程序与该程序的依赖，打包在一个文件里面。运行这个文件，就会生成一个虚拟容器。程序在这个虚拟容器里运行，就好像在真实的物理机上运行一样。有了 Docker，就不用担心环境问题。
---

上面说了那么多，就是为了解释为什么要使用Docker，让大家有一个感性的认识。下面介绍一下Docker的入门使用。

### Docker的用途
Docker 的主要用途，目前有三大类。

（1）提供一次性的环境。**比如，本地测试他人的软件、持续集成的时候提供单元测试和构建的环境。

（2）提供弹性的云服务。**因为 Docker 容器可以随开随关，很适合动态扩容和缩容。

（3）组建微服务架构。**通过多个容器，一台机器可以跑多个服务，因此在本机就可以模拟出微服务架构。

### Docker安装

```
#yum-util 提供 yum-config-manager 功能，另外两个是 devicemapper 驱动依赖的
yum install -y yum-utils device-mapper-persistent-data lvm2
#设置 yum 源
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
#安装最新稳定版 docker
yum install docker-ce
#启动
systemctl start docker
#加入开机启动
systemctl enable docker
#验证安装是否成功
docker version

```

### Docker简单使用

```
#拉取镜像
docker pull 镜像名

#运行镜像文件
docker container run 文件名

docker start :启动一个或多个已经被停止的容器

docker stop :停止一个运行中的容器

docker restart :重启容器

`docker start [OPTIONS] CONTAINER [CONTAINER...]`
`docker stop [OPTIONS] CONTAINER [CONTAINER...]`
`docker restart [OPTIONS] CONTAINER [CONTAINER...]`
```
更多命令参考[这里](https://www.runoob.com/docker/docker-command-manual.html) 。




