title: JVM系列之JVM类加载机制
date: '2019-10-15 20:18:32'
updated: '2020-11-10 11:13:33'
tags: [JVM]
permalink: /articles/2019/10/15/1571141911966.html
---
![](https://img.hacpai.com/bing/20180509.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 引言

在开始说类是如何加载的话题前，在这里放一张Java程序是如何执行的图，看一下类的加载处在什么位置。

- 代码编译

![image.png](https://img.hacpai.com/file/2019/10/image-33b67511.png)

- 字节码执行

![image.png](https://img.hacpai.com/file/2019/10/image-7cb3128d.png)

Java代码编译和执行的整个过程包含了以下三个重要的机制：

* Java源码编译机制
* 类加载机制
* 类执行机制

在这里我们只讨论类的加载机制。

## 类加载机制的概念

> 在编译过程中，我们编写的java源代码文件经过Java编译器编译为.class的文件，.class文件中保存着Java代码经转换后的虚拟机指令，当需要使用某个类时，虚拟机将会加载它的.class文件，并创建对应的class对象，将class文件加载到虚拟机的内存，这个过程就称为类加载。

类加载过程如下图：

![image.png](https://img.hacpai.com/file/2019/10/image-d6ccac53.png)

```text
❀ 加载：查找和导入Class文件；

  ❀ 链接：把类的二进制数据合并到JRE中；

     (a)验证：检查载入Class文件数据的正确性；

     (b)准备：给类的静态变量分配存储空间；

     (c)解析：将符号引用转成直接引用；

  ❀ 初始化：对类的静态变量，静态代码块执行初始化操作
```

## 类加载器

> 类加载器的作用是根据一个类的全限定名查找.class文件，读取它的二进制流，并把创建java.lang.Class文件加载到虚拟机的内存中。

### 如何确定是同一个类

类的唯一性是由类的本身和它的类加载器决定的，也就是说两个类来源于同一个Class文件，并且被同一个类加载器加载，这两个类才相等。

### 几种类加载器

虚拟机提供了3种类加载器，引导（Bootstrap）类加载器、扩展（Extension）类加载器、系统（System）类加载器（也称应用类加载器）。

- 引导类类加载器（Bootstrap Classloader）
  引导类加载器主要加载JVM自身需要的类，它使用C++语言实现，是虚拟机自身的一部分，它负责将 <JAVA_HOME>/lib 路径下的核心类库或-Xbootclasspath参数指定的路径下的jar包加载到内存中，由于虚拟机是按照文件名识别并加载jar包的，如果文件名不被虚拟机识别，即使把jar包丢到lib目录下也是没有作用的，出于安全考虑，Bootstrap启动类加载器只加载包名为java、javax、sun等开头的类。
- 扩展类加载器（Extension Classloader）
  扩展类加载器是指Sun公司实现的sun.misc.Launcher$ExtClassLoader类，由Java语言实现的，是Launcher的静态内部类，它负责加载<JAVA_HOME>/lib/ext目录下或者由系统变量-Djava.ext.dir指定位路径中的类库，开发者可以直接使用标准扩展类加载器。
- 系统类加载器（System Classloader）
  系统类加载器也称应用程序加载器是指 Sun公司实现的sun.misc.Launcher$AppClassLoader。它负责加载系统类路径java -classpath或-D java.class.path 指定路径下的类库，也就是我们经常用到的classpath路径，开发者可以直接使用系统类加载器，一般情况下该类加载器是程序中默认的类加载器，通过ClassLoader#getSystemClassLoader()方法可以获取到该类加载器。

除此之外，开发者还可以自己定义类加载器。**Java虚拟机对class文件采用的是按需加载的方式**，也就是说当需要使用该类时才会将它的class文件加载到内存生成Class对象，而且加载某个类的class文件时，Java虚拟机采用的是双亲委派模式即把请求交由父类处理。

## 双亲委派模式

系统中的 ClassLoder 在协同工作的时候会默认使用 **双亲委派模型** 。即在类加载的时候，系统会首先判断当前类是否被加载过。已经被加载的类会直接返回，否则才会尝试加载。加载的时候，首先会把该请求委派该父类加载器的 `loadClass()` 处理，因此所有的请求最终都应该传送到顶层的启动类加载器 `BootstrapClassLoader` 中。当父类加载器无法处理时，才由自己来处理。当父类加载器为null时，会使用启动类加载器 `BootstrapClassLoader` 作为父类加载器。

> 简单来说就是，一个类要加载，首先找他的长辈去加载。长辈不能加载了，在委托给各自的儿子。

![image.png](https://img.hacpai.com/file/2019/10/image-857c3bb7.png)

### 基本实现源码

```java
private final ClassLoader parent; 
protected Class<?> loadClass(String name, boolean resolve)
        throws ClassNotFoundException
    {
        synchronized (getClassLoadingLock(name)) {
            // 首先，检查请求的类是否已经被加载过
            Class<?> c = findLoadedClass(name);
            if (c == null) {
                long t0 = System.nanoTime();
                try {
                    if (parent != null) {//父加载器不为空，调用父加载器loadClass()方法处理
                        c = parent.loadClass(name, false);
                    } else {//父加载器为空，使用启动类加载器 BootstrapClassLoader 加载
                        c = findBootstrapClassOrNull(name);
                    }
                } catch (ClassNotFoundException e) {
                   //抛出异常说明父类加载器无法完成加载请求
                }
                
                if (c == null) {
                    long t1 = System.nanoTime();
                    //自己尝试加载
                    c = findClass(name);

                    // this is the defining class loader; record the stats
                    sun.misc.PerfCounter.getParentDelegationTime().addTime(t1 - t0);
                    sun.misc.PerfCounter.getFindClassTime().addElapsedTimeFrom(t1);
                    sun.misc.PerfCounter.getFindClasses().increment();
                }
            }
            if (resolve) {
                resolveClass(c);
            }
            return c;
        }
    }
```

双亲委派模型保证了Java程序的稳定运行，可以避免类的重复加载（JVM 区分不同类的方式不仅仅根据类名，相同的类文件被不同的类加载器加载产生的是两个不同的类），也保证了 Java 的核心 API 不被篡改。如果没有使用双亲委派模型，而是每个类加载器加载自己的话就会出现一些问题，比如我们编写一个称为 `java.lang.Object` 类的话，那么程序运行的时候，系统就会出现多个不同的 `Object` 类。

必要的时候还可以自己写一个类加载器，只要继承自ClassLoader，重写其方法即可。

### 能不能自己写一个```java.lang.System```的类？

不能。要么不能加载进内存，要么即使你用自定义的类加载器去强行加载，也会收到一个SecurityException。详细可以参考这篇博客---> [链接](https://blog.csdn.net/tang9140/article/details/42738433)

<center> <b>❤ 转载请注明本文地址或来源，谢谢合作 ❤</b></center>

---

![wx.png](https://b3logfile.com/file/2020/11/扫码搜索联合传播样式标准色版-ccc1b679.png)


