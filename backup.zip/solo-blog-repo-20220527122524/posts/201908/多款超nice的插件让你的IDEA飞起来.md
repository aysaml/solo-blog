title: 多款超nice的插件让你的IDEA飞起来
date: '2019-08-19 17:51:56'
updated: '2020-11-10 11:15:50'
tags: [IDEA]
permalink: /articles/2019/08/19/1566208316096.html
---
![](https://img.hacpai.com/bing/20171205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### IDEA，目前流行java开发工具。使用起来，不仅让javaer惊叹它的强大功能，在流畅编码的同时，IDEA也为我们带来了强大的插件库。今天就为大家推荐多款好用的插件。

1. **插件安装**
   preferences->plugins
   或者你也可以从IDEA官方的插件库下载，然后选择从磁盘安装：				https://plugins.jetbrains.com/idea
   ![image.png](https://img.hacpai.com/file/2019/08/image-618f6957.png)
2. **Background Image Plus**
   IDAE的背景图片修改插件，让你的编辑界面更炫酷，但是不建议设置色彩特别亮的图片哦，这样代码的颜色容易会被图片盖过去，不容易查看，当然也可以设置图片的透明度来调整。
   ![image.png](https://img.hacpai.com/file/2019/08/image-4d09a0e4.png)
3. **Free Mybatis plugin**
   一款免费的mybatis插件，还有一款是收费的。有了这个插件，mapper.xml可以像java接口一样可以快速跳跃，代码补全。
   **dao**
   ![image.png](https://img.hacpai.com/file/2019/08/image-333a4e98.png)
   
   **xml**
   ![image.png](https://img.hacpai.com/file/2019/08/image-b253af08.png)
4. **MyBatis Log Plugin**
   在开启mybatis的sql日志打印时，打印出来的sql是不能直接执行的，安装了这个插件后，就可以直接将mybatis执行的sql打印出来，直接复制出来就可以执行了。
5. **Lombok**
   使用这个插件，就不用在pojo等地方写一些看起来特别冗余的getter,setter，toString等啦。只需要使用对应的注解就可以实现了。
   
   详细参考：	[lombok的使用](http://www.aysaml.com/articles/2019/05/05/1557055419936.html)
6. **Alibaba Java Coding Guidelines**
   阿里规约插件，如果代码不符合阿里代码规范时，会有黄线提示，同时可以进行扫描，对日常养成良好的编码风格和习惯很有帮助。
   ![image.png](https://img.hacpai.com/file/2019/08/image-33cec34e.png)
7. **Translation**
   翻译插件，快捷方便。英语渣渣的首选！告别命名头疼的烦恼。
   ![image.png](https://img.hacpai.com/file/2019/08/image-ad9bcf94.png)
8. **Rainbow Brackets**
   对括号着色，方便查看代码结构。
9. **Gsonformat**
   能够把json直接转换成java的实体类。
   使用时，新建一个java类，复制要解析的josn串，然后使用快捷键command + n新建GsonFormat就行啦。
   ![image.png](https://img.hacpai.com/file/2019/08/image-8541ef6e.png)
10. ****Power mode II****
    最后一个压轴的啦，是一个没什么用的装X插件，敲代码时整个屏幕都会抖，然后还有火焰特效，哈哈哈哈。不过非常占内存，注意把IDEA的运行内存调高一些啊。

好了，本次就推荐这些了啊，用好插件，事半功倍。

<center> <b>❤ 转载请注明本文地址或来源，谢谢合作 ❤</b></center>

---

![wx.png](https://b3logfile.com/file/2020/11/扫码搜索联合传播样式标准色版-ccc1b679.png)


