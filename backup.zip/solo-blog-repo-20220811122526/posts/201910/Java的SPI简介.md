title: Java的SPI简介
date: '2019-10-18 17:53:02'
updated: '2020-11-10 11:12:59'
tags: [JDK, SPI]
permalink: /articles/2019/10/18/1571392382274.html
---
![](https://img.hacpai.com/bing/20190506.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 概述

> SPI（Service Provider Interface） , 是JDK内置的一种服务提供发现机制，为某个接口寻找服务的机制,类似IOC思想，将装配的控制权交给ServiceLoader，可以动态加载接口实现类。

SPI只提供服务接口，具体服务由其他组件实现，接口和具体实现分离（类似桥接），同时能够`通过系统的ServiceLoader`拿到这些实现类的集合，统一处理，这样在组件化中往往会带来很多便利，SPI机制可以实现不同模块之间方便的面向接口编程，拒绝了硬编码的方式，解耦效果很好。

## 实现方式

- 首先有一个示例服务

### SpiDemoService 接口

```java
package com.aysaml.dubbo.spi.service;

/**
 * SPI示例服务接口
 *
 * @author aysaml
 * @date 2019-10-18
 */
public interface SpiDemoService {

  /**
   * hello示例
   *
   * @param name
   * @return
   */
  String hello(String name);
}
```

### SpiDemoServiceImpl实现

```java
package com.aysaml.dubbo.spi.service.impl;

import com.aysaml.dubbo.spi.service.SpiDemoService;

/**
 * SPI示例服务实现
 *
 * @author aysaml
 * @date 2019-10-18
 */
public class SpiDemoServiceImpl implements SpiDemoService {

  @Override
  public String hello(String name) {
    System.out.println("hello " + name);
    return "hello " + name;
  }
}
```

- 在META-INF/services/下新建一个名为这个服务的全限定名的文件，其内容为这个服务的实现的全限定名，如果有多个实现，换行添加。

### META-INF/services/com.aysaml.dubbo.spi.service.SpiDemoService

```
# 实现

com.aysaml.dubbo.spi.service.impl.SpiDemoServiceImpl
```

### 使用ServiceLoader调用服务

```java
package com.aysaml.dubbo.spi.test;

import com.aysaml.dubbo.spi.service.SpiDemoService;

import java.util.Iterator;
import java.util.ServiceLoader;

/**
 * SPI测试
 *
 * @author aysaml
 * @date 2019-10-18
 */
public class SpiTest {
  public static void main(String[] args) {
      ServiceLoader<SpiDemoService> services = ServiceLoader.load(SpiDemoService.class);
      Iterator<SpiDemoService> iterator = services.iterator();
      if(null != iterator && iterator.hasNext()){
          SpiDemoService spiDemoService = iterator.next();
          spiDemoService.hello("SPI");
      }
  }
}
```

### 效果

![image.png](https://img.hacpai.com/file/2019/10/image-4681881a.png)

代码github地址>>>[戳这里](https://github.com/wangning1018/dubbo-learning/tree/master/src/main/java/com/aysaml/dubbo/spi)

<center> <b>❤ 转载请注明本文地址或来源，谢谢合作 ❤</b></center>

---

![wx.png](https://b3logfile.com/file/2020/11/扫码搜索联合传播样式标准色版-ccc1b679.png)


