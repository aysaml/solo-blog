title: JVM体系结构概览
date: '2019-05-28 17:25:15'
updated: '2019-07-23 14:43:09'
tags: [JVM]
permalink: /articles/2019/05/28/1559035515379.html
---
![](https://img.hacpai.com/bing/20180903.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 之前的工作中很少接触到JVM层级的东西，对JVM仅停留在一些理论中，对整体的结构也一知半解，知识比较零散，这段时间会系统的了解学习一下JVM相关知识，力求有一个系统结构的掌握，后面也会把笔者所学所想整理出一个JVM专题，希望通过这个专题的阅读，能够对大家了解JVM的体系结构和基本知识有所帮助。

- 下图是整个JVM知识体系的构图

![JVM.jpg](https://img.hacpai.com/file/2019/05/JVM-4db0db32.jpg)

- 另提供一个精美清晰的PPT

	 [JVM体系结构与GC调优.pptx.zip](https://img.hacpai.com/file/2019/05/JVM体系结构与GC调优.pptx-193670d2.zip)

- 还有JVM的经典著作《深入理解Java虚拟机：JVM高级特性与最佳实践（第2版）》电子书
	> 电子版仅供阅读交流使用，支持作者请购买实体书>>[点击链接](https://item.jd.com/11252778.html)
	百度网盘链接：[点击下载](https://pan.baidu.com/s/1oFKpXwgHxpFVPchXSMvpfw)  	| 密码:cj0w

	以上，是部分学习资料。
	同时，后面整个JVM专题的文章目录也会整理到下面。

---

- [JVM内存结构](http://www.aysaml.com/articles/2019/05/29/1559110466401.html)
- [java内存模型](http://www.aysaml.com/articles/2019/06/05/1559715975334.html)
- JVM类加载机制
- GC算法 垃圾收集器
- GC分析
- GC调优
- JVM调优
- JVM面试知识点
- java8 新特性

---
### 附件
[JVM整理.docx.zip](https://img.hacpai.com/file/2019/07/JVM整理.docx-899392e1.zip)

		‘愿所有的努力不被时光辜负’





