title: JVM系列之JVM内存结构
date: '2019-05-29 14:14:26'
updated: '2019-09-18 15:37:58'
tags: [JVM]
permalink: /articles/2019/05/29/1559110466401.html
---
![](https://img.hacpai.com/bing/20180813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### JVM概览

---
先来看一下JVM是什么，由什么组成的？

``` JVM = 类加载器(class loader) + 执行引擎(execution engine) + 运行时数据区域(runtime data area) ```
![image.png](https://img.hacpai.com/file/2019/09/image-9afbd608.png)

本篇我们主要讲运行时数据区这块，在下一篇，我们会说一下类加载的部分。

### 运行时数据区

---
![image.png](https://img.hacpai.com/file/2019/09/image-035bc44d.png)


大体来看，JVM的运行时数据区分为堆、栈、方法区。从上图可以看出，堆和方法区是线程共享的，而栈和程序计数器由每个线程单独持有。

### 程序计数器（Program Counter Register）

*   线程私有，**它的生命周期与线程相同。**
*   可以看做是当前线程所执行的字节码的行号指示器。
*   在虚拟机的概念模型里（仅是概念模型，各种虚拟机可能会通过一些更高效的方式去实现），字节码解释器工作时就是通过改变这个计数器的值来选取下一条需要执行的字节码指令，如：分支、循环、跳转、异常处理、线程恢复（**多线程切换**）等基础功能。
*    如果线程正在执行的是一个Java方法，这个计数器记录的是正在执行的虚拟机字节码指令的地址；如果正在执行的是Natvie方法，这个计数器值则为空（undefined）。
*   程序计数器中存储的数据所占空间的大小不会随程序的执行而发生改变，所以此区域不会出现OutOfMemoryError的情况。  
    

### Java虚拟机栈（JVM Stacks）

*   线程私有的，**它的生命周期与线程相同。**
*   **虚拟机栈描述的是Java方法执行的内存模型**：每个方法被执行的时候都会同时创建一个栈帧（Stack Frame）用于存储局部变量表、操作栈、动态链接、方法出口等信息。**每一个方法被调用直至执行完成的过程，就对应着一个栈帧在虚拟机栈中从入栈到出栈的过程。**
*   **局部变量表**存放了编译期可知的各种基本数据类型（boolean、byte、char、short、int、float、long、double）、对象引用（reference类型），它不等同于对象本身，根据不同的虚拟机实现，它可能是一个指向对象起始地址的引用指针，也可能指向一个代表对象的句柄或者其他与此对象相关的位置）和returnAddress类型（指向了一条字节码指令的地址）。**局部变量表所需的内存空间在编译期间完成分配，当进入一个方法时，这个方法需要在帧中分配多大的局部变量空间是完全确定的，在方法运行期间不会改变局部变量表的大小。**
*   该区域可能抛出以下异常：
    1.  当线程请求的栈深度超过最大值，会抛出 StackOverflowError异常；
    2.  栈进行动态扩展时如果无法申请到足够内存，会抛出 OutOfMemoryError 异常。

### 本地方法栈（Native Method Stacks）

*   与虚拟机栈非常相似，其区别不过是虚拟机栈为虚拟机执行Java方法（也就是字节码）服务，而**本地方法栈则是为虚拟机使用到的Native 方法服务**。虚拟机规范中对本地方法栈中的方法使用的语言、使用方式与数据结构并没有强制规定，因此具体的虚拟机可以自由实现它。甚至有的虚拟机（譬如Sun HotSpot 虚拟机）直接就把本地方法栈和虚拟机栈合二为一。
*   与虚拟机栈一样，本地方法栈区域也会抛出StackOverflowError和OutOfMemoryError异常。

### Java堆（Heap）

*   被所有**线程共享**，在虚拟机启动时创建，用来存放对象实例，**几乎所有的对象实例都在这里分配内存**。
*   对于大多数应用来说，Java堆（Java Heap）是Java虚拟机所管理的内存中**最大**的一块。
*   Java堆是垃圾收集器管理的主要区域，因此很多时候也被称做“**GC堆**”。如果从内存回收的角度看，由于现在收集器基本都是采用的分代收集算法，所以Java堆中还可以细分为：**新生代和老年代；新生代又有Eden空间、From Survivor空间、To Survivor空间三部分**。
*   Java 堆不需要连续内存，并且可以通过动态增加其内存，增加失败会抛出 OutOfMemoryError 异常。
  

### 方法区（Method Area）

*   用于存放已被加载的类信息、常量、静态变量、即时编译器编译后的代码等数据。
*   和 Java 堆一样不需要连续的内存，并且可以动态扩展，动态扩展失败一样会抛出 OutOfMemoryError 异常。
*   对这块区域进行垃圾回收的主要目标是对**常量池的回收和对类的卸载**，但是一般比较难实现，HotSpot 虚拟机把它当成永久代（Permanent Generation）来进行垃圾回收。
*   方法区逻辑上属于堆的一部分，但是为了与堆进行区分，通常又叫“非堆”。

运行时常量池（Runtime Constant Pool）

*   运行时常量池是方法区的一部分。
*   Class 文件中的常量池（编译器生成的各种字面量和符号引用）会在类加载后被放入这个区域。
*   除了在编译期生成的常量，还允许动态生成，例如 String 类的 intern()。这部分常量也会被放入运行时常量池。
 

注：

*   在 JDK1.7之前，HotSpot 使用永久代实现方法区；HotSpot 使用 GC 分代实现方法区带来了很大便利；
*   从 JDK1.7 开始HotSpot 开始移除永久代。其中符号引用（Symbols）被移动到 Native Heap中，字符串常量和类引用被移动到 Java Heap中。
*   在 JDK1.8 中，永久代已完全被元空间(Meatspace)所取代。元空间的本质和永久代类似，都是对JVM规范中方法区的实现。不过元空间与永久代之间最大的区别在于：**元空间并不在虚拟机中，而是使用本地内存。因此，默认情况下，元空间的大小仅受本地内存限制。**

  

### 直接内存（Direct Memory）

*   直接内存（Direct Memory）并不是虚拟机运行时数据区的一部分，也不是Java虚拟机规范中定义的内存区域，但是这部分内存也被频繁地使用，而且也可能导致OutOfMemoryError 异常出现。
*   在 JDK 1.4 中新加入了 NIO 类，引入了一种基于通道（Channel）与缓冲区（Buffer）的 I/O方式，它可以使用 Native 函数库直接分配堆外内存，然后通过一个存储在 Java 堆里的 DirectByteBuffer 对象作为这块内存的引用进行操作。这样能在一些场景中显著提高性能，因为避免了在Java 堆和 Native 堆中来回复制数据。

### 哪儿的OutOfMemoryError

对内存结构清晰的认识同样可以帮助理解不同OutOfMemoryErrors：

```


Exception  in thread “main”: java.lang.OutOfMemoryError:  Java heap space
    


```

原因：对象不能被分配到堆内存中

```


Exception  in thread “main”: java.lang.OutOfMemoryError:  PermGen space
    


```

原因：类或者方法不能被加载到老年代。它可能出现在一个程序加载很多类的时候，比如引用了很多第三方的库；

```


Exception  in thread “main”: java.lang.OutOfMemoryError:  Requested array size exceeds VM limit
    


```

原因：创建的数组大于堆内存的空间

```


Exception  in thread “main”: java.lang.OutOfMemoryError: request <size> bytes for  <reason>.  Out of swap space?
    


```

原因：分配本地分配失败。JNI、本地库或者Java虚拟机都会从本地堆中分配内存空间。

```


Exception  in thread “main”: java.lang.OutOfMemoryError:  <reason>  <stack trace>（Native method）
    


```

原因：同样是本地方法内存分配失败，只不过是JNI或者本地方法或者Java虚拟机发现
