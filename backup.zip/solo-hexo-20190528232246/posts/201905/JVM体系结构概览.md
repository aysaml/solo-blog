title: JVM体系结构概览
date: '2019-05-28 17:25:15'
updated: '2019-05-28 18:49:04'
tags: [JVM]
permalink: /articles/2019/05/28/1559035515379.html
---
![](https://img.hacpai.com/bing/20180903.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> 之前的工作中很少接触到JVM层级的东西，对JVM仅停留在一些理论中，对整体的结构也一知半解，知识比较零散，这段时间会系统的了解学习一下JVM相关知识，力求有一个系统结构的掌握，后面也会把笔者所学所想整理出一个JVM专题，希望通过这个专题的阅读，能够让大家对JVM的体系结构和基本知识有一个清晰的了解有所帮助。

- 下图是整个JVM知识体系的构图

![JVM.jpg](https://img.hacpai.com/file/2019/05/JVM-4db0db32.jpg)

- 另提供一个精美清晰的PPT

	 [JVM体系结构与GC调优.pptx.zip](https://img.hacpai.com/file/2019/05/JVM体系结构与GC调优.pptx-193670d2.zip)

- 还有JVM的经典著作《深入理解Java虚拟机：JVM高级特性与最佳实践（第2版）》电子书
	> 电子版仅供阅读交流使用，支持作者请购买实体书>>[点击链接](https://item.jd.com/11252778.html)
	百度网盘链接：[点击下载](https://pan.baidu.com/s/1oFKpXwgHxpFVPchXSMvpfw)  	| 密码:cj0w

	以上，是部分学习资料。
	同时，后面整个JVM专题的文章目录也会整理到下面。

---

- JVM内存模型
- JVM内存结构
- JVM类加载机制
- GC算法 垃圾收集器
- GC分析
- GC调优
- JVM调优
- JVM面试知识点
- java8 新特性

		‘愿所有的努力不被时光辜负’





