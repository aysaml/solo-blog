title: 随机生成32位uuid工具类
date: '2019-05-05 15:36:33'
updated: '2019-05-05 15:36:44'
tags: [java, 常用工具类]
permalink: /articles/2019/05/05/1557041792956.html
---
![](https://img.hacpai.com/bing/20190215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

利用java提供的uuid生成工具类生成随机的32uuid。

```
import java.util.UUID;

/**
 * uuid工具类
 *
 * @author wangning40
 * @date 2019-05-05
 **/
public class UuidUtil {
  /**
   * 获得随机32位uuid
   *
   * @return
   */
  public static String get32Uuid() {
    String uuid = UUID.randomUUID().toString().trim().replaceAll("-","");
    return uuid;
  }
}
```