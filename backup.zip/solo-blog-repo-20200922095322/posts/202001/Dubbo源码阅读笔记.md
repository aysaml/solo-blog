title: Dubbo源码阅读笔记
date: '2020-01-04 17:41:28'
updated: '2020-09-21 15:40:43'
tags: [目录]
permalink: /articles/2020/01/04/1578130888106.html
---
![](https://img.hacpai.com/bing/20190706.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

[Apache Dubbo™](http://dubbo.apache.org/zh-cn/) 是一款高性能 Java RPC 框架。不同于其他博客，一上来就是讲怎么怎么用，我们将从 Dubbo 重要的核心特性和步骤入手，来学习 Dubbo 架构如何实现连通性、健壮性、伸缩性、以及向未来架构的升级性。

---

![](https://img.hacpai.com/file/2020/01/image-45d86a88.png)

## 文章列表

### 《[Dubbo 系列笔记之项目结构](https://aysaml.com/articles/2019/11/15/1573790514430.html)》

### 《[Dubbo 系列笔记之特殊示例用法](https://aysaml.com/articles/2019/12/14/1576312634579.html)》

### 《[Dubbo 系列笔记之 XML 配置文件解析流程](https://aysaml.com/articles/2019/09/18/1568797105593.html)》

### 《[Dubbo 系列笔记之 SPI 实现](https://aysaml.com/articles/2019/12/17/1576579214365.html)》

### 《[Dubbo 系列笔记之自适应扩展机制](https://aysaml.com/articles/2019/12/20/1576840669968.html)》

### 《[Dubbo系列笔记之zookeeper注册中心原理](https://aysaml.com/articles/2020/08/17/1597658280603.html)》

### 《[Dubbo系列笔记之服务暴露过程](https://aysaml.com/articles/2020/09/04/1599206156889.html)》

### 《[Dubbo系列笔记之服务引用过程](https://aysaml.com/articles/2020/09/08/1599558950363.html)》

#### 持续更新中...❤️

