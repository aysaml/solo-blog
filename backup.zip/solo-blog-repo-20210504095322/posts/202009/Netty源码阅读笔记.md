title: Netty 源码阅读笔记
date: '2020-09-23 18:23:37'
updated: '2020-12-22 17:12:39'
tags: [目录]
permalink: /articles/2020/09/23/1600856617447.html
---
![](https://b3logfile.com/bing/20200811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

[Netty](https://netty.io/) 是一款基于 NIO 客户、服务器端的 Java 开源编程框架，提供异步的、事件驱动的网络应用程序框架和工具，用以快速开发高性能、高可靠性的网络服务器和客户端程序。

全文基于源码 **Netty 4.1** ，望知悉。

![](https://img.hacpai.com/file/2019/12/components-3d7f0874.png)

## 文章列表

## ❀ 领略 Netty 大不同

[《Netty 系列笔记之开篇》](https://aysaml.com/articles/2020/09/21/1600675546715.html)

## ❀ 击破 Netty 知识点

[《Netty 系列笔记之三种 IO 模式》](https://aysaml.com/articles/2020/09/25/1601016054028.html)

[《Netty 系列笔记之 NIO 核心组件 Channel》](https://aysaml.com/articles/2020/10/12/1602491893054.html)

[《Netty 系列笔记之 NIO 核心组件 Buffer》](https://aysaml.com/articles/2020/10/16/1602830946887.html)

[《Netty 系列笔记之 Java NIO 核心组件 Selector》](https://aysaml.com/articles/2020/10/21/1603251555158.html)

[《Netty 系列笔记之 Reactor 模式》](https://aysaml.com/articles/2020/10/23/1603444872972.html)

[《Netty 系列笔记之 TCP 粘包拆包与编解码》](https://aysaml.com/articles/2020/10/27/1603780674945.html)

[《Netty 系列笔记之 keepalive 与 idle 监测》](https://aysaml.com/articles/2020/10/28/1603876845195.html)

[《Netty 系列笔记之内存管理》](https://aysaml.com/articles/2020/11/03/1604391401499.html)

## ❀ 总览 Netty 启动线

[《Netty 系列笔记之源码分析：启动服务》](https://aysaml.com/articles/2020/11/05/1604559009881.html)

[《Netty 系列笔记之源码分析：创建连接》](https://aysaml.com/articles/2020/11/10/1604993259018.html)

[《Netty 系列笔记之源码分析：接收数据》](https://aysaml.com/articles/2020/11/11/1605080681091.html)

[《Netty 系列笔记之源码分析：业务处理》](https://aysaml.com/articles/2020/12/10/1607584619326.html)

[《Netty 系列笔记之源码分析：发送数据》](https://aysaml.com/articles/2020/12/14/1607929679383.html)

## ❀ 搞定 Netty 核心源码

#### 持续更新中...❤️

