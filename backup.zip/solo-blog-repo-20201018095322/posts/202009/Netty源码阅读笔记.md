title: Netty 源码阅读笔记
date: '2020-09-23 18:23:37'
updated: '2020-10-16 14:44:17'
tags: [目录]
permalink: /articles/2020/09/23/1600856617447.html
---
![](https://b3logfile.com/bing/20200811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

[Netty](https://netty.io/) 是一款基于 NIO 客户、服务器端的 Java 开源编程框架，提供异步的、事件驱动的网络应用程序框架和工具，用以快速开发高性能、高可靠性的网络服务器和客户端程序。

![](https://img.hacpai.com/file/2019/12/components-3d7f0874.png)

## 文章列表

## 《[Netty 系列笔记之开篇](https://aysaml.com/articles/2020/09/21/1600675546715.html)》

## 《[Netty 系列笔记之三种 IO 模式](https://aysaml.com/articles/2020/09/25/1601016054028.html)》

## 《[Netty 系列笔记之 NIO 核心组件 Channel](https://aysaml.com/articles/2020/10/12/1602491893054.html)》

#### 持续更新中...❤️

