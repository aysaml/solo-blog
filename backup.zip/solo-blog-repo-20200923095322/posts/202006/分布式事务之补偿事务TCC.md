title: 分布式事务之补偿事务（ TCC ）
date: '2020-06-16 18:55:57'
updated: '2020-07-14 10:53:33'
tags: [分布式事务]
permalink: /articles/2020/06/16/1592304957424.html
---
![](https://img.hacpai.com/bing/20180613.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、TCC 是什么
TCC 全称 Try Confirm Cancle 。从字面意思可以理解，TCC 为了实现分布式事务解决了 XA 协议的三个问题：1.协调者单点故障；2.同步阻塞；3.数据一致性。

![image.png](https://b3logfile.com/file/2020/06/image-6d33f97d.png)

TCC 的主要思想是针对每个操作，都要注册一个与其对应的确认和补偿（撤销）操作。

*  Try 阶段：尝试执行，完成所有业务检查（一致性），留必须业务资源（准隔离性）。

*  Confirm 阶段：确认执行，真正执行业务，不作任何业务检查，只使用Try阶段预留的业务资源，Confirm 操作满足幂等性。要求具备幂等设计，Confirm 失败后需要进行重试。

*  Cancel 阶段：取消执行，释放 Try 阶段预留的业务资源 ，Cancel操作满足幂等性。Cancel 阶段的异常和 Confirm 阶段异常处理方案基本上一致。

### 二、Java 中使用 TCC
常用的有 ByteTCC、himly、tcc-transaction 等。

框架按照 demo 来就行了，需要实现的是一个接口的三种状态，比如要修改一个订单的状态为已付款，那么按照 TCC 的思想就要有下面三个方法来实现事务：

- 1. Try : 订单状态更新态，将订单状态改为 UPDATE。
- 2. Confirm：确认订单状态修改，将订单状态改为已付款。
- 3. Cancle：取消订单状态的修改，一旦发生错误，则使用此方法做数据回滚。


关于 TCC ，更多请参考：[《如何理解TCC分布式事务?》](https://www.zhihu.com/question/48627764)



