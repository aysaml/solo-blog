title: 我在 GitHub 上的开源项目
date: '2019-09-17 10:37:55'
updated: '2019-09-17 10:37:55'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/wangning1018/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wangning1018/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/wangning1018/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangning1018/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://aysaml.com`](https://aysaml.com "项目主页")</span>

码恋 - ALL YOUR SMILES, ALL MY LIFE.



---

### 2. [cns-web](https://github.com/wangning1018/cns-web) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wangning1018/cns-web/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/wangning1018/cns-web/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangning1018/cns-web/network/members "分叉数")</span>

辽宁石油化工大学校园导航系统前台项目



---

### 3. [campus-navigation](https://github.com/wangning1018/campus-navigation) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wangning1018/campus-navigation/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/wangning1018/campus-navigation/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangning1018/campus-navigation/network/members "分叉数")</span>

辽宁石油化工大学校园导航系统



---

### 4. [cns-backstage-vue](https://github.com/wangning1018/cns-backstage-vue) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wangning1018/cns-backstage-vue/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/wangning1018/cns-backstage-vue/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangning1018/cns-backstage-vue/network/members "分叉数")</span>

校园导航后台vue项目



---

### 5. [spring-boot-aop](https://github.com/wangning1018/spring-boot-aop) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wangning1018/spring-boot-aop/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wangning1018/spring-boot-aop/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wangning1018/spring-boot-aop/network/members "分叉数")</span>

spring-boot-aop实现多数据源读写分离

