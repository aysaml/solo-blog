title: Dubbo系列笔记之项目结构
date: '2019-11-15 12:01:54'
updated: '2020-11-10 11:12:09'
tags: [dubbo]
permalink: /articles/2019/11/15/1573790514430.html
---
![](https://img.hacpai.com/bing/20190602.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 关于 `Dubbo` ， 最初是只想取一些比较重要的地方去做记录，但是总感觉知识学得比较零散，一块一块的，所以最近准备 Skr~Dubbo 了。

**学习 Dubbo 的第一步，从头至尾，先把[官方文档](http://dubbo.apache.org/zh-cn/docs/user/quick-start.html)看一遍！！！**

## 1. 概述

> Dubbo 版本，本系列笔记基于 Dubbo 2.6.5，后续代码可能有部分基于官方 github 最新代码，请知悉 。

推荐先阅读 Duubbo 的官方文档：http://dubbo.apache.org/zh-cn/index.html

在 Dubbo 笔记的本篇，主要对 Dubbo 的整体项目结构有一个比较清晰的认知，知道 Dubbo 是如何分层的，以及它的整体调用过程。

## 2. 调试环境搭建

- Fork Dubbo
  首先阅读一个源码之前，建议大家可以先 Fork 到自己的仓库，方便阅读的时候添加注释。
- clone 到本地
  这里选择 Dubbo 的 2.6.5 版本，资料比较多，支持了 Dubbo 的绝大多少特性。

```text
git clone https://github.com/wangning1018/dubbo.git
	git checkout dubbo-2.6.5
```

- 搭建本地 `Zookeeper` 环境
  Dubbo 官方比较推荐的是使用 Zookeeper 作为注册中心，所以在一开始调试，就选择 Zookeeper ，而不是用 Demo 中默认的  `MulticastRegistry` 作为调试注册中心，注意 `MulticastRegistry` 仅适用于小规模的或者开发模式。

安装并启动 Zookeeper 。

- 配置文件修改
  修改 dubbo-demo 中 consumer 和 provider 的注册中心配置为 Zookeeper 。
  
  `<dubbo:registry address="zookeeper://127.0.0.1:2181"/>`

## 3. 整体结构一览

![image.png](https://img.hacpai.com/file/2019/11/image-d2a97987.png)

可以看到 Dubbo 分成了许多模块，下面我们简单说一下每个模块的功能。

![image.png](https://img.hacpai.com/file/2019/11/image-d8ca8932.png)

上图是取自 Dubbo 官网的项目模块分包图，列举了 8 个主要的模块，可以很清晰的看出它们之间的依赖关系。

下面自源码的从上到下，简单看一下每个模块都是做什么的。

### 3.1 `dubbo-all` 打包模块

这个模块里面只有一个 `pom.xml` ，是 Dubbo 的 maven 打包脚本。

### 3.2 `dubbo-bom` 依赖管理模块

同样，里面只有一个 `pom.xml` ，通过 Maven 的 `<dependencyManagement>` 统一定义了 Dubbo 项目本身每个包的版本。

### 3.3 `dubbo-dependencies-bom` 第三方依赖版本管理模块

历史再一次同样，该模块是 Dubbo 对所依赖的第三方 jar 包进行了一个统一管理，通过这样一个 bom 后续再项目中做引入，就可以保证同一个 jar 包版本的一致性，避免依赖冲突。

关于 Maven BOM 的更多详细内容参见 [《Maven中BOM》](https://blog.csdn.net/LoveJavaYDJ/article/details/86594226) 这篇博客。

### 3.4 `dubbo-distribution`  打包存放模块

Dubbo 准备 # Apache Release 会打包到此目录。

### 3.5 `dubbo-bootstrap` 启动模块

这个模块里只有 `DubboBootstrap` 这一个类，负责启动 `Dubbo` 。

### 3.6 `dubbo-cluster` 集群模块

集群模块负责把多个服务提供者封装为一个，并提供负载均衡, 集群容错，路由，分组聚合等功能，集群的地址列表可以静态配置，也可以由配置中心下发。

![image.png](https://img.hacpai.com/file/2019/11/image-b7d4e887.png)

上图展示了集群模块的基本包结构，下面我们分别来看一下相关功能大体是由哪些组成的。

#### ❀ 容错

- 由 `com.alibaba.dubbo.rpc.cluster.Cluster` 接口和 `com.alibaba.dubbo.rpc.cluster.support` 包实现
- `Cluster` 将 `Directory` 中的多个 `Invoker` 封装为一个 `Invoker` ，对上层透明，并在这个过程中加入了容错逻辑，调用失败后，尝试调用下一个 `Invoker` 。

#### ❀ 配置

- 由 `com.alibaba.dubbo.rpc.cluster.Configurator` 接口和 `com.alibaba.dubbo.rpc.cluster.configurator` 包实现
- 这里支持从**服务**和**应用**两个粒度来调整动态配置，实现了无需重启应用的情况下，就可以动态调整RPC调用行为。

#### ❀ 字典

- 由 `com.alibaba.dubbo.rpc.cluster.Directory` 接口和 `com.alibaba.dubbo.rpc.cluster.directory` 包实现
- 主要功能就是存放 Invoker ，用一个 List 实现，Directory 中 Invoker 的值可以通过注册中心推送来进行动态的变更。

#### ❀ 负载均衡

- 由 `com.alibaba.dubbo.rpc.cluster.LoadBalance` 接口和 `com.alibaba.dubbo.rpc.cluster.loadbalance` 包实现。
- 实现多个 Invoker 的负载均衡，这里实现了四种均衡策略，默认是随机调用策略。

#### ❀ 合并结果

- 由 `com.alibaba.dubbo.rpc.cluster.Merger` 接口和 `com.alibaba.dubbo.rpc.cluster.merger` 包组成。
- 实现对返回结果的合并，简单来说就是一个接口有多种实现，消费者需要一一调用这些实现，并实现结果的合并返回。比如菜单服务，接口一样，但有多种实现，用group区分，现在消费方需从每种group中调用一次返回结果，合并结果返回，这样就可以实现聚合菜单项。
- 参见 Dubbo 官方的例子： https://github.com/apache/dubbo-samples/tree/master/dubbo-samples-merge

#### ❀ 路由

- 由 `com.alibaba.dubbo.rpc.cluster.Router` 接口和 `com.alibaba.dubbo.rpc.cluster.router` 包组成
- 路由规则在发起一次RPC调用前起到过滤目标服务器地址的作用，过滤后的地址列表，将作为消费端最终发起RPC调用的备选地址。
- 详细参见 [《Dubbo 官方文档 -- 路由规则》](http://dubbo.apache.org/zh-cn/docs/user/demos/routing-rule.html)

下面是 Dubbo 官网的调用关系图：

![image.png](https://img.hacpai.com/file/2019/11/image-554a95b3.png)

具体参考 [《Dubbo 集群容错》](http://dubbo.apache.org/zh-cn/docs/user/demos/fault-tolerent-strategy.html)

### 3.7 `dubbo-common` 公共逻辑模块

这个模块主要是一些工具类和通用模型。

![image.png](https://img.hacpai.com/file/2019/11/image-d318d780.png)

可以看到里面一堆的各种 util 和 一些通用模型：比如：`com.alibaba.dubbo.common.URL ` 。

### 3.8 `dubbo-config` 配置模块

是 Dubbo 对外的 API，用户通过 Config 使用Dubbo，隐藏 Dubbo 所有细节。

### 3.9 `dubbo-container` 容器模块

这个模块是一个 Standlone 的容器，以简单的 Main 加载 Spring 启动，因为服务通常不需要 Tomcat/JBoss 等 Web 容器的特性，没必要用 Web 容器去加载服务。

* `dubbo-container-api` ：定义了 `com.alibaba.dubbo.container.Container` 接口，里面包含了容器的 `start()` 和 `stop()` 方法，并提供加载所有容器启动的 Main 类。
* 实现 `dubbo-container-api`
  * `dubbo-container-spring` ，提供了 `com.alibaba.dubbo.container.spring.SpringContainer` 。
  * `dubbo-container-log4j` ，提供了 `com.alibaba.dubbo.container.log4j.Log4jContainer` 。
  * `dubbo-container-logback` ，提供了 `com.alibaba.dubbo.container.logback.LogbackContainer` 。

### 3.10 `dubbo-demo` 示例模块

提供 Spring 形式的提供者和消费者示例代码，可以使用这个模块进行基础调试，观察服务的暴露和消费过程。

### 3.11 `dubbo-filter` 过滤器模块

![image.png](https://img.hacpai.com/file/2019/11/image-b9c37e02.png)

* `dubbo-filter-cache` ，缓存过滤器。
  * 对调用返回的结果做缓存。
* `dubbo-filter-validation` ，参数验证过滤器。
  * 参数验证功能是基于 [JSR303](https://jcp.org/en/jsr/detail?id=303) 实现的，用户只需标识 JSR303 标准的验证 annotation，并通过声明 filter 来实现验证。具体参考：[《Dubbo 官方文档 -- 参数验证》](http://dubbo.apache.org/zh-cn/docs/user/demos/parameter-validation.html)。

### 3.12 `dubbo-monitor` 监控模块

统计服务调用次数，调用时间的，调用链跟踪的服务。顺便提一下，调用链路追踪现在 Skywalking 比较流行。

### 3.13 `dubbo-plugin` 插件模块

顾名思义，为用户提供插件。

![image.png](https://img.hacpai.com/file/2019/11/image-65c95b2e.png)

目前就一个在线运维命令的插件。

### 3.14 `dubbo-registry` 注册中心模块

![image.png](https://img.hacpai.com/file/2019/11/image-126500e8.png)

* `dubbo-registry-api` 定义了一个注册中心需要实现的注册、发现逻辑接口。
* 其他的是注册中心的不同实现，官方推荐使用 Zookeeper 作为注册中心。

### 3.15 `dubbo-remoting` 远程通讯模块

![image.png](https://img.hacpai.com/file/2019/11/image-288379c9.png)

相当于 Dubbo 协议的实现，如果 RPC 用 RMI协议则不需要使用此包。

* 里面封装了各种客户端和服务端的通信方式实现。

### 3.16 `dubbo-rpc` 远程调用模块

![image.png](https://img.hacpai.com/file/2019/11/image-6a1c7230.png)

这个模块抽象了各种协议，以及动态代理，只包含一对一的调用，不关心集群的管理。

* `dubbo-rpc-api` ，**抽象**各种协议以及动态代理，**实现**了一对一的调用。
* 其他模块，实现 `dubbo-rpc-api` ，提供对应的协议实现。在 [《用户指南 —— 协议参考手册》](http://dubbo.apache.org/zh-cn/docs/user/references/protocol/introduction.html) 中，可以看到每种协议的介绍。
* Dubbo 默认使用 dubbo 协议。
* 这个模块是整个 Dubbo 的中心，需要我们详细了解。

### 3.17 `dubbo-serialization` 数据序列化模块

![image.png](https://img.hacpai.com/file/2019/11/image-fcd182b0.png)

可以看到实现了多种方式做对象序列化工作。

### 3.18 `dubbo-test` 测试模块

涵盖了比较完整的 Dubbo 测试，可以用来了解每个功能点的实现特性。

---

上面用了较长的篇幅一一介绍了 Dubbo 源码中每个 maven 模块的用途，其实总结起来就是 Dubbo 的十层架构设计，如下图：

![image.png](https://img.hacpai.com/file/2019/11/image-1d88af76.png)

> 图例说明：
> 
> * 图中左边淡蓝背景的为服务消费方使用的接口，右边淡绿色背景的为服务提供方使用的接口，位于中轴线上的为双方都用到的接口。
> * 图中从下至上分为十层，各层均为单向依赖，右边的黑色箭头代表层之间的依赖关系，每一层都可以剥离上层被复用，其中，Service 和 Config 层为 API，其它各层均为 SPI。
> * 图中绿色小块的为扩展接口，蓝色小块为实现类，图中只显示用于关联各层的实现类。
> * 图中蓝色虚线为初始化过程，即启动时组装链，红色实线为方法调用过程，即运行时调时链，紫色三角箭头为继承，可以把子类看作父类的同一个节点，线上的文字为调用的方法。

---

### 整体架构

![image.png](https://img.hacpai.com/file/2019/11/image-9ee5385a.png)

> 图例说明：
> 
> * 图中小方块 Protocol, Cluster, Proxy, Service, Container, Registry, Monitor 代表层或模块，蓝色的表示与业务有交互，绿色的表示只对 Dubbo 内部交互。
> * 图中背景方块 Consumer, Provider, Registry, Monitor 代表部署逻辑拓扑节点。
> * 图中蓝色虚线为初始化时调用，红色虚线为运行时异步调用，红色实线为运行时同步调用。
> * 图中只包含 RPC 的层，不包含 Remoting 的层，Remoting 整体都隐含在 Protocol 中。

---

### 调用链

展开总设计图的红色调用链，如下：

![image.png](https://img.hacpai.com/file/2019/11/image-5b149148.png)

---

### 暴露服务时序

展开总设计图左边服务提供方暴露服务的蓝色初始化链，时序图如下：

![image.png](https://img.hacpai.com/file/2019/11/image-bfff82e1.png)

### 引用服务时序

展开总设计图右边服务消费方引用服务的蓝色初始化链，时序图如下：

![image.png](https://img.hacpai.com/file/2019/11/image-e1ebc696.png)

<center> <b>❤ 转载请注明本文地址或来源，谢谢合作 ❤</b></center>

---

![wx.png](https://b3logfile.com/file/2020/11/扫码搜索联合传播样式标准色版-ccc1b679.png)


