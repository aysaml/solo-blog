title: 通过Nginx代理实现https方式访问网站
date: '2019-09-18 15:22:46'
updated: '2023-03-18 14:45:51'
tags: [https, nginx]
permalink: /articles/2019/09/18/1568791365834.html
---
![](https://img.hacpai.com/bing/20190416.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、什么是 HTTPS

---

HTTPS（**H**yper**T**ext **T**ransfer **P**rotocol **S**ecure），超文本安全传输协议，是一种通过[计算机网络](https://zh.wikipedia.org/wiki/%E8%A8%88%E7%AE%97%E6%A9%9F%E7%B6%B2%E7%B5%A1)进行安全通信的[传输协议](https://zh.wikipedia.org/wiki/%E7%B6%B2%E8%B7%AF%E5%82%B3%E8%BC%B8%E5%8D%94%E5%AE%9A)。HTTPS 经由[HTTP](https://zh.wikipedia.org/wiki/HTTP)进行通信，但利用[SSL/TLS](https://zh.wikipedia.org/wiki/%E4%BC%A0%E8%BE%93%E5%B1%82%E5%AE%89%E5%85%A8)来[加密](https://zh.wikipedia.org/wiki/%E5%8A%A0%E5%AF%86)数据包。HTTPS 开发的主要目的，是提供对[网站](https://zh.wikipedia.org/wiki/%E7%B6%B2%E7%AB%99)服务器的[身份认证](https://zh.wikipedia.org/wiki/%E8%BA%AB%E4%BB%BD%E9%AA%8C%E8%AF%81)，保护交换数据的隐私与[完整性](https://zh.wikipedia.org/wiki/%E5%AE%8C%E6%95%B4%E6%80%A7)。这个协议由[网景](https://zh.wikipedia.org/wiki/%E7%B6%B2%E6%99%AF)公司（Netscape）在 1994 年首次提出，随后扩展到[互联网](https://zh.wikipedia.org/wiki/%E7%B6%B2%E9%9A%9B%E7%B6%B2%E8%B7%AF)上。

历史上，HTTPS 连接经常用于[万维网](https://zh.wikipedia.org/wiki/%E4%B8%87%E7%BB%B4%E7%BD%91)上的交易支付和企业信息系统中敏感信息的传输。在 2000 年代末至 2010 年代初，HTTPS 开始广泛使用，以确保各类型的网页真实，保护账户和保持用户通信，身份和网络浏览的私密性。---维基百科

---

### 二、 操作步骤

---

1. 申请SSL证书

各大云厂商都可以申请免费版的SSL证书，我是用的阿里云的免费SSL证书，更多的免费证书可参考这篇博客，?[更多免费证书](https://blog.csdn.net/ithomer/article/details/78075006)。
证书提供了多种类型，下载后的Nginx证书文件像下面这样：

![image.png](https://img.hacpai.com/file/2019/09/image-e38c1f7c.png)

2.下载Nginx

可以使用docker方式使用Nginx,或者直接使用```yum -y install nginx```命令安装。

* 启动Nginx服务
  ```service nginx start```
* 停止Nginx服务
  ```service nginx stop ```
* 重启Nginx服务
  ```service nginx restart```

使用```nginx -t```命令查看Nginx的配置文件路径，编辑配置文件```vi /etc/nginx/nginx.conf```,如下

```
user  nginx;
worker_processes  1;

error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile        on;
    #tcp_nopush     on;

    keepalive_timeout  65;

    #gzip  on;

 #后端的服务器，此处就是服务器的访问地址端口
    upstream backend {
        server localhost:8080 max_fails=3 fail_timeout=30s;
    }

 #此处是额外的配置
    include /usr/local/soloconf/*.conf;
}
```

接下来配置SSL证书，将证书文件上传到服务器，```cd [Nginx的配置文件目录下]```,```rz```上传文件，可以使用支持rz的shell终端，这里推荐使用SecureCRT:

```
server {
        listen 443 ssl;
	#这里改成自己的域名
        server_name aysaml.com www.aysaml.com;
        # 配置上面两个证书文件路径，注意是相对于Nginx配置文件的路径
        ssl_certificate 2131395_aysaml.com.pem;
        ssl_certificate_key 2131395_aysaml.com.key;
        ssl_session_timeout 5m;

        location / {
            proxy_pass http://backend$request_uri;
            proxy_set_header Host $host:$server_port;
            proxy_set_header X-Real-IP  $remote_addr;
            proxy_set_header http_x_forwarded_for $remote_addr;
            client_max_body_size 10m;
        }
    }
    server {
        # http跳转到https
        listen 80;
        server_name aysaml.com www.aysaml.com;
        rewrite ^(.*)$  https://$host$1 permanent;
    }
```

配置完成后，重启Nginx使配置生效，```service nginx restart```。

做完这些，就可以让你的网站有小锁头啦，搜索引擎也会优先展示收录https访问方式的网站哦~


