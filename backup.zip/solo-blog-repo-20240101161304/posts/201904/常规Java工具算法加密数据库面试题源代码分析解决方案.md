title: 常规Java工具，算法，加密，数据库，面试题，源代码分析，解决方案
date: '2019-04-30 19:48:14'
updated: '2019-04-30 19:50:07'
tags: [java, 工具类]
permalink: /articles/2019/04/30/1556624894280.html
---
![](https://img.hacpai.com/bing/20190326.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

分享一个特别有用的github。

[地址](https://github.com/scalad/Note)


### 常规Java工具，算法，加密，数据库，面试题，源代码分析，解决方案

  

有家杂志曾对全国60岁以上的老人进行了这样一次问卷调查:你最后悔什么?

列出10项人们生活中容易后悔的事情，供被调查者选择，回收有效问卷并进行统计分析后，竟得出了这样的结果。

**第一名:年轻时不够努力，导致一事无成(75%)**

[![](https://github.com/silence940109/Java/raw/master/image/desktop1.jpg)](https://github.com/silence940109/Java/blob/master/image/desktop1.jpg)

所谓少壮不努力，老大徒伤悲。青春岁月里，又常常碰到那么多的诱惑甚至陷阱，当你猛然醒悟时，也许白发早生，竟然一事无成。

趁着你还有时间、有精力、有体力，赶快制定一个切实可行的计划，然后开始百折不挠一路向前，老来回忆，少些遗憾。

**第二名:年轻的时候选错了职业(70%)**

[![](https://github.com/silence940109/Java/raw/master/image/desktop2.jpg)](https://github.com/silence940109/Java/blob/master/image/desktop2.jpg)

三个大学生被同时分配到某机关工作，一年后，其中一个由于不甘心整天看主管脸色，跳槽到另一家企业去了，另外两位依旧安稳地过着朝九晚五的日子。又一年后，另外一个学生决定辞职下海，剩下那个依然没有动心。

若干年后，三人相聚，到企业去的那位同学成了高管，下海的那位成了千万富翁，而留在机关的那位却依旧在领导的呵斥声中消磨着自己所剩无几的“大好时光”。

许多人在选择职业时考虑的第一因素就是稳定的收入和安稳舒适的生活，而不太愿意去面对那些具有挑战性的机会。没有了压力，自然就缺乏了动力，没有了动力，也就埋没了潜力。

**第三名:对子女教育不当(62%)**

[![](https://github.com/silence940109/Java/raw/master/image/desktop13.jpg)](https://github.com/silence940109/Java/blob/master/image/desktop13.jpg)

孩子是自己生命、希望的延续，许多人为了孩子可以倾尽所有，但望子成龙、盼女成凤可能只是父母单方面的良好愿望。对于儿女而言，他们也许只是想做一个简单快乐的平凡人。

许多父母采取了强制、监督甚至棍棒等方式来逼迫孩子按照自己设计的线路发展。可到最后，多数父母却不得不在对现实感到失望，只有极少数所谓的“成功者”例外。他们也不由地感叹孩子这些年过得太苦，没有享受到应有的快乐与阳光。

**第四名:没好好珍惜自己的伴侣(57%)**

[![](https://github.com/silence940109/Java/raw/master/image/desktop4.jpg)](https://github.com/silence940109/Java/blob/master/image/desktop4.jpg)

醉过方知酒浓，爱过方知情重。感情，总是拥有时不懂得珍惜，失去后才知道珍贵。人类永远发明不出的两种物质，一是忘情水，二是后悔药。年轻的时候不去珍惜、体谅和理解，待到年老时，后悔已经来不及。

**第五名:没有善待自己的身体(49%)**

[![](https://github.com/silence940109/Java/raw/master/image/desktop5.jpg)](https://github.com/silence940109/Java/blob/master/image/desktop5.jpg)

“身体是革命的本钱”，这句话永远都不会过时，许多人在60岁前用身体去换取一切，在60岁以后又用一切去换取身体的健康。

世界上没有什么东西比自己的健康更加重要，没有一个好的身体，纵有千万家产又如何?