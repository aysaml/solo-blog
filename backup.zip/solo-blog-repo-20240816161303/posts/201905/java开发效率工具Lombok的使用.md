title: java开发效率工具-Lombok的使用
date: '2019-05-05 19:23:39'
updated: '2019-08-26 15:50:27'
tags: [java]
permalink: /articles/2019/05/05/1557055419936.html
---
![](https://img.hacpai.com/bing/20181008.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 导语
写够了CURD，还有一堆样式模板固定的POJO的getter/setter等等，笔者认为，能够工具生成的代码绝不手写，能够不写的代码绝不多写。So,有了Lombok，和那些烦人的样板代码说拜拜吧。

### Lombok的使用

Lombok的使用非常简单，如下：

1） 引入maven依赖
```
<dependency> 
	<groupId>org.projectlombok</groupId>
	 <artifactId>lombok</artifactId> 
	<version>1.16.18</version> 
	<scope>provided</scope> 
</dependency>
```

2） IDEA安装Lombok插件

3）注解

@Getter/@Setter: 作用类上，生成所有成员变量的getter/setter方法；作用于成员变量上，生成该成员变量的getter/setter方法。可以设定访问权限及是否懒加载等。

---

@ToString：作用于类，覆盖默认的toString()方法，可以通过of属性限定显示某些字段，通过exclude属性排除某些字段。

---

@EqualsAndHashCode：作用于类，覆盖默认的equals和hashCode

---

@NonNull：主要作用于成员变量和参数中，标识不能为空，否则抛出空指针异常。

---

@NoArgsConstructor, @RequiredArgsConstructor, @AllArgsConstructor：作用于类上，用于生成构造函数。有staticName、access等属性。

---

@NoArgsConstructor：生成无参构造器；

@RequiredArgsConstructor：生成包含final和@NonNull注解的成员变量的构造器；

@AllArgsConstructor：生成全参构造器。

---

@Data：作用于类上，是以下注解的集合：@ToString @EqualsAndHashCode @Getter @Setter @RequiredArgsConstructor

---

@Builder：作用于类上，将类转变为建造者模式

---

@Log：作用于类上，生成日志变量。针对不同的日志实现产品，有不同的注解;

---

@Cleanup：自动关闭资源，针对实现了java.io.Closeable接口的对象有效，如：典型的IO流对象

---

@SneakyThrows：可以对受检异常进行捕捉并抛出。

---

@Synchronized：作用于方法级别，可以替换synchronize关键字或lock锁，不常用。


